# -*- coding: utf-8 -*-
from odoo import Command
from odoo.exceptions import ValidationError
from odoo.tests import tagged

from .common import DwCommon


@tagged("post_install", "-at_install", "dw_manufacturing")
class TestRuleEngine(DwCommon):
    """The component / quantity engine must be exact, safe and configurable."""

    def setUp(self):
        super().setUp()
        self.family = self.env["dw.product.family"].create({
            "name": "Test Fence",
            "code": "TFENCE",
            "product_kind": "fence",
            "quantity_method": "length",
            "company_id": self.company.id,
            "dimension_ids": self._dims(
                "length", "height", "post_count", "section_count",
                "post_spacing", "weld_length", "paint_area",
            ),
        })
        self.item = self.env["dw.opening"].create({
            "family_id": self.family.id,
            "finished_product_id": self.product_fence.id,
            "company_id": self.company.id,
            "length_mm": 20000.0,
            "height_mm": 2000.0,
            "post_spacing_mm": 2500.0,
            "quantity": 1.0,
        })

    # ------------------------------------------------------------------
    def test_01_derived_measurements(self):
        item = self.item
        self.assertAlmostEqual(item.length_m, 20.0)
        self.assertAlmostEqual(item.height_m, 2.0)
        self.assertAlmostEqual(item.area_m2, 40.0)
        self.assertAlmostEqual(item.perimeter_m, 44.0)
        self.assertAlmostEqual(item.total_length_m, 20.0)
        # 20 m at 2.5 m spacing -> 8 spans, 9 posts
        self.assertEqual(item.section_count, 8)
        self.assertEqual(item.post_count, 9)

    def test_02_single_variable_rule(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Mesh by area",
            "family_id": self.family.id,
            "component_product_id": self.mat_mesh.id,
            "calc_method": "variable",
            "basis": "area",
            "factor": 1.0,
            "waste_percent": 10.0,
            "company_id": self.company.id,
        })
        # 40 m2 + 10 % waste
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 44.0, places=6)

    def test_03_guided_formula_no_eval(self):
        """post_count x height x 1.05 built from ordered typed terms."""
        rule = self.env["dw.component.rule"].create({
            "name": "Posts",
            "family_id": self.family.id,
            "component_product_id": self.mat_tube50.id,
            "calc_method": "formula",
            "company_id": self.company.id,
            "term_ids": [
                Command.create({"sequence": 1, "operand_type": "variable", "variable": "post_count"}),
                Command.create({"sequence": 2, "operator": "*", "operand_type": "variable", "variable": "height"}),
                Command.create({"sequence": 3, "operator": "*", "operand_type": "constant", "constant_value": 1.05}),
            ],
        })
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 9 * 2.0 * 1.05, places=6)
        self.assertIn("Post Count", rule.formula_preview)

    def test_04_formula_operators_are_left_to_right(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Steps minus one",
            "family_id": self.family.id,
            "component_product_id": self.mat_tube40.id,
            "calc_method": "formula",
            "company_id": self.company.id,
            "term_ids": [
                Command.create({"sequence": 1, "operand_type": "variable", "variable": "length"}),
                Command.create({"sequence": 2, "operator": "+", "operand_type": "constant", "constant_value": 4.0}),
                Command.create({"sequence": 3, "operator": "*", "operand_type": "constant", "constant_value": 2.0}),
            ],
        })
        # (20 + 4) * 2 = 48, strictly left to right, not 20 + (4 * 2)
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 48.0, places=6)

    def test_05_division_by_zero_is_safe(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Divide by empty variable",
            "family_id": self.family.id,
            "component_product_id": self.mat_tube40.id,
            "calc_method": "formula",
            "company_id": self.company.id,
            "term_ids": [
                Command.create({"sequence": 1, "operand_type": "variable", "variable": "length"}),
                Command.create({"sequence": 2, "operator": "/", "operand_type": "variable", "variable": "step_count"}),
            ],
        })
        self.assertEqual(rule.calculate_quantity(self.item), 0.0)

    def test_06_commercial_length_rounding(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Rails in 6 m bars",
            "family_id": self.family.id,
            "component_product_id": self.mat_tube40.id,
            "calc_method": "variable",
            "basis": "length",
            "factor": 2.0,
            "round_commercial": True,
            "commercial_length_m": 6.0,
            "commercial_output": "length",
            "company_id": self.company.id,
        })
        # 40 m needed -> 7 bars of 6 m -> 42 m
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 42.0, places=6)
        rule.commercial_output = "pieces"
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 7.0, places=6)

    def test_07_rounding_modes_and_minimum(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Rounded pieces",
            "family_id": self.family.id,
            "component_product_id": self.mat_hinge.id,
            "calc_method": "variable",
            "basis": "height",
            "factor": 1.3,
            "round_mode": "up",
            "company_id": self.company.id,
        })
        # 2.0 x 1.3 = 2.6 -> 3
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 3.0)
        rule.round_mode = "down"
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 2.0)
        rule.round_mode = "nearest"
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 3.0)
        rule.round_mode = "none"
        rule.min_qty = 10.0
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 10.0)

    def test_08_rounding_multiple(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Sheet in half units",
            "family_id": self.family.id,
            "component_product_id": self.mat_sheet.id,
            "calc_method": "variable",
            "basis": "area",
            "factor": 0.13,
            "rounding_multiple": 0.5,
            "round_mode": "up",
            "company_id": self.company.id,
        })
        # 40 x 0.13 = 5.2 -> 5.5
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 5.5, places=6)

    def test_09_conditions_gate_the_rule(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Extra bracing on tall fences",
            "family_id": self.family.id,
            "component_product_id": self.mat_tube40.id,
            "calc_method": "variable",
            "basis": "length",
            "factor": 1.0,
            "company_id": self.company.id,
            "condition_ids": [
                Command.create({"variable": "height", "operator": ">", "value": 2.5}),
            ],
        })
        self.assertEqual(rule.calculate_quantity(self.item), 0.0)
        self.item.height_mm = 3000.0
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 20.0)

    def test_10_conversion_factor_and_extra(self):
        rule = self.env["dw.component.rule"].create({
            "name": "Paint litres",
            "family_id": self.family.id,
            "component_product_id": self.mat_paint.id,
            "calc_method": "variable",
            "basis": "paint_area",
            "factor": 1.0,
            "conversion_factor": 0.125,
            "extra_qty": 0.0,
            "company_id": self.company.id,
        })
        expected = self.item.paint_area_m2 * 0.125
        self.assertAlmostEqual(rule.calculate_quantity(self.item), expected, places=6)
        rule.extra_qty = 2.0
        self.assertAlmostEqual(
            rule.calculate_quantity(self.item),
            (self.item.paint_area_m2 + 2.0) * 0.125,
            places=6,
        )

    def test_11_negative_values_rejected(self):
        with self.assertRaises(ValidationError):
            self.env["dw.component.rule"].create({
                "name": "Bad rule",
                "family_id": self.family.id,
                "component_product_id": self.mat_tube40.id,
                "calc_method": "variable",
                "basis": "area",
                "factor": -1.0,
                "company_id": self.company.id,
            })

    def test_12_formula_needs_terms(self):
        with self.assertRaises(ValidationError):
            self.env["dw.component.rule"].create({
                "name": "Empty formula",
                "family_id": self.family.id,
                "component_product_id": self.mat_tube40.id,
                "calc_method": "formula",
                "company_id": self.company.id,
            })

    def test_13_engine_never_evaluates_code(self):
        """A string that looks like code can only ever be stored as a label."""
        rule = self.env["dw.component.rule"].create({
            "name": "__import__('os').system('echo pwned')",
            "family_id": self.family.id,
            "component_product_id": self.mat_tube40.id,
            "calc_method": "variable",
            "basis": "area",
            "factor": 1.0,
            "company_id": self.company.id,
        })
        self.assertAlmostEqual(rule.calculate_quantity(self.item), 40.0)
        # The engine exposes no field that carries an expression to evaluate.
        for field_name in ("basis", "calc_method"):
            self.assertIn(field_name, rule._fields)
        self.assertNotIn("expression", rule._fields)
        self.assertNotIn("python_code", rule._fields)

    def test_14_legacy_rule_still_matches(self):
        """Phase 1 rules have no family: they must keep matching by product."""
        legacy_item = self.env["dw.opening"].create({
            "finished_product_id": self.product_door.id,
            "company_id": self.company.id,
            "opening_type": "door",
            "width_mm": 1000.0,
            "height_mm": 2100.0,
            "quantity": 2.0,
        })
        legacy_rule = self.env["dw.component.rule"].create({
            "name": "Legacy perimeter rule",
            "finished_product_tmpl_id": self.product_door.product_tmpl_id.id,
            "opening_type": "door",
            "component_product_id": self.mat_tube40.id,
            "basis": "perimeter",
            "factor": 1.0,
            "waste_percent": 10.0,
            "company_id": self.company.id,
        })
        rules = self.env["dw.component.rule"]._rules_for_item(legacy_item)
        self.assertIn(legacy_rule, rules)
        self.assertAlmostEqual(
            legacy_rule.calculate_quantity(legacy_item), 6.2 * 1.1, places=6
        )
